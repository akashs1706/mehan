<?php
$list = adminemployersstatus($_GET['id']);
header('Location: /employers');
									
									