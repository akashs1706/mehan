<?php
$list = adminemployersdelete($_GET['id']);
header('Location: /employers');
									
									