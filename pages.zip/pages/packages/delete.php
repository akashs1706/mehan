<?php
$list = packagedelete($_GET['id']);
header('Location: /packages');
									
									