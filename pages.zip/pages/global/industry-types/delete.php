<?php
$list = adminindustorytypesdelete($_GET['id']);
header('Location: /global/industry-types');
									
									