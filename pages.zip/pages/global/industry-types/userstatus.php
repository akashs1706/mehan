<?php
$list = adminindustorytypesstatus($_GET['id']);
header('Location: /global/industry-types');
									
									