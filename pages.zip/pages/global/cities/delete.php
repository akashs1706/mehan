<?php
$list = admindeletecities($_GET['id']);
header('Location: /global/cities');
									
									