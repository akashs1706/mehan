<?php
$list = adminstatuscities($_GET['id']);
header('Location: /global/cities');
									
									