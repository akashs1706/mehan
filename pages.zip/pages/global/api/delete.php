<?php
$list = deleteAPI($_GET['id']);
header('Location: /global/api');
									
									