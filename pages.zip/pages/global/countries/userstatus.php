<?php
$list = admincountriesstatus($_GET['id']);
header('Location: /global/countries');
									
									