<?php
$list = admincountriesdelete($_GET['id']);
header('Location: /global/countries');
									
									