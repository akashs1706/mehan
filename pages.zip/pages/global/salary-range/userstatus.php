<?php
$list = adminsalaryrangestatus($_GET['id']);
header('Location: /global/salary-range');
									
									