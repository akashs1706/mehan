<?php
$list = admindeletesalaryrange($_GET['id']);
header('Location: /global/salary-range');
									
									