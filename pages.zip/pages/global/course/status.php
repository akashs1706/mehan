<?php
$list = statusCoursescategory($_GET['id']);
header('Location: /global/course');
									
									