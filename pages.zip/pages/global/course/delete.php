<?php
$list = deleteCoursescategory($_GET['id']);
header('Location: /global/course');
									
									