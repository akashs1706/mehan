<?php
$list = adminstatuscandidatesdegree($_GET['id']);
header('Location: /global/candidates-degree');
									
									