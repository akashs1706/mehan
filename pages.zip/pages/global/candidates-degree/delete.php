<?php
$list = admindeletecandidatesdegree($_GET['id']);
header('Location: /global/candidates-degree');
									
									