<?php
$list = adminstatusstates($_GET['id']);
header('Location: /global/states');
									
									