<?php
$list = admindeletestates($_GET['id']);
header('Location: /global/states');
									
									