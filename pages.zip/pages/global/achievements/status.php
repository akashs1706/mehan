<?php
$list = statusAchievement($_GET['id']);
header('Location: /global/achievements');
									
									