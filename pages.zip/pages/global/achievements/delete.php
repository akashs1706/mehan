<?php
$list = deleteAchievement($_GET['id']);
header('Location: /global/achievements');
									
									