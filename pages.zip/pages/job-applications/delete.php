<?php
$list = applicationdelete($_GET['id']);
header('Location: /job-applications');
									
									