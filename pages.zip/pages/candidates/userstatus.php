<?php
$list = admincandidatesstatus($_GET['id']);
header('Location: /candidates');
									
									