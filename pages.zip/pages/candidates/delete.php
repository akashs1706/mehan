<?php
$list = admincandidatesdelete($_GET['id']);
header('Location: /candidates');
									
									