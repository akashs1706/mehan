<?php
$list = jobcatdelete($_GET['id']);
header('Location: /jobcategories');
									
									