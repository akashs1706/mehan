<?php
$list = adminuserstatus($_GET['id']);
header('Location: /admin');
									
									