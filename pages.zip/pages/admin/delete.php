<?php
$list = adminuserdelete($_GET['id']);
header('Location: /admin');
									
									