<?php
$list = jobdelete($_GET['id']);
header('Location: /jobs');
									
									