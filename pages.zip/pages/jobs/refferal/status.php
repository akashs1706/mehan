<?php
$list = statusRefferal($_GET['id']);
header('Location: /jobs/refferal');
									
									