<?php
$list = deleteRefferal($_GET['id']);
header('Location: /jobs/refferal');
									
									